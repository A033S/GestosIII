# A Blank PhoneGap App

## Usage

### PhoneGap CLI

    $ phonegap create my-app --template blank

### Desktop

In your browser, open the file:

    /www/index.html

